# Lab 4

@1400012789 倪蕴哲

CLFSLab 原理性实现。

作者注：本文非常长，且包含大量引用（绝大部分是前向的，后向引用已经被尽可能减少了），阅读时请善用查找功能。

## 通信协议

典型的通信过程是（以put操作为例）：

1. 客户端发送一个`CLFSRequest`对象到客户端  
2. 服务器端收到此对象，发送一个随机字节到客户端以同步  
3. 客户端发送文件，若文件过大则分段。每段的长度最大为`bufferSize`字节  
4. 在每次客户端发送一段文件后，服务器端发送一个随机字节到客户端以同步  
5. 任务终止，服务器端发送一个`CLFSResponse`对象到客户端  

可以对通信过程进行一个抽象的描述，即确定操作类型后，则服务器和客户端各自需要发送的信息是确定的，它们会在之后自动按照各自的顺序发送信息。而发信者每次发送（一段）信息后，收信者需要发送一个字节到送信者处（这个字节可能是随机字节，也可能带有信息，具体视操作类型而定），发信者只有在收到回执后才会进行下一步操作（除非是服务器在发送`CLFSResponse`）。在发送信息时，如果发信者需要发送的信息长度超过`bufferSize`，则需要分段发送。

我们没有使用类似HTTP的先发送报头后发送报文的方法来实现服务器，是因为我们在发送文件的每一个阶段都可能出错，而且我们需要实现的功能是固定的，就算没有收到报头，客户端和服务器的行为也是完全可预期的。

在通信过程中，我们设定了等待时限`timeOut`，若服务器等待信息的时长超过`timeOut`秒，则服务器会终止当前任务并试图发送`CLFSResponse`（不考虑是否出错），此次通信会被判定为失败。客户端也有等待时限`timeOut`，若在任务进行中等待时长达到时限，则客户端会终止任务并试图接收一个`CLFSResponse`，若这个过程中等待时长达到时限，则客户端会生成一个默认的错误返回对象代替服务器的回复。

我们的`bufferSize`参数默认值是65536，`timeOut`参数默认值是60。

## 云端服务器的实现

由于并不是在内核中使用服务器，我在此处使用了较为擅长的`java`语言来实现之。

### 进行网络通信

实现的核心部分首先是`NetComm`包。它是`java`中网络字节流的简单封装。其中包含的类是`NetReader`和`NetWriter`类。

对于`NetReader`类，需要关注的重点是`blockCount`方法。它实现了“阻塞直到可以读取指定数量的字节”的功能。其代码如下：

```java
private void blockCount(long count)
    throws IOException, TimeOutException
{
    int cnt = 0;
    while (out.available() < count)
    {
        try
        {
            Thread.sleep(10);
        }
        catch (Exception e) {}
        if (++cnt == 6000)
        {
            throw new TimeOutException(
                "Time out after " + cnt + " attempts.");
        }
    }
}
```

我们看到，这个方法同样提供了timeout特性。在这个方法的基础上，我们可以进一步实现更高层的`readByteBin`，`readIntBin`，`readN`方法（其功能可参考名称）

对于`NetWriter`类，我们的实现是，当调用类中的`write`方法时，仅仅将数据放入缓冲区，而只有当`flush`被调用时，我们才会将数据真正发出（也就是说，如果不`flush`，`write`将没有任何效果），这是为了使我们在发送小段数据时不再需要多次接收。

### 实现服务器

服务器的基本架构是基于线程池的多线程模型实现的，即主线程初始化`ServerSocket`完成后，将会被专用于监听，而每当一个连接请求到达，主线程会试图向线程池请求一个工作线程`CLFSWorker`，并令之处理请求。`CLFSWorker`类用于实现此部分功能的代码如下：

```java

class CLFSWorker extends Thread
{
    static public final int maxWorker = 32;
    static int workerCount = 0;

    static synchronized public int modifyWorkerCount(int delta)
    {
        return workerCount += delta;
    }

    static public int readWorkerCount()
    {
        return modifyWorkerCount(0);
    }

    private CLFSWorker() {}

    static public CLFSWorker makeWorker(ServerSocket server)
        throws Exception
    {
        while (readWorkerCount() == maxWorker)
        {
            try
            {
                Thread.sleep(100);
            }
            catch (Exception e) {}
        }
        
        modifyWorkerCount(1);
        CLFSWorker res =  new CLFSWorker();

        res.connect = server.accept();      
        res.connect.setReceiveBufferSize(Util.bufferSize << 1);
        res.connect.setSendBufferSize(Util.bufferSize << 1);
        res.is = new NetReader(res.connect.getInputStream());
        res.os = new NetWriter(res.connect.getOutputStream());

        return res;
    }
    // ...
}
```

可以看到，`CLFSWorker`对象不能被外部程序用构造函数创建，要获得对象实例，必须调用`makeWorker`方法。而在`makeWorker`方法中，我们使用循环查询+睡眠的方式等待工作线程数降到最大值以下，而所有对共享变量`workerCount`的访问都需要通过管程`modifyWorkerCount`进行。由此我们就实现了一个简单的线程池。可以看到，在创建线程时，我们调用了`modifyWorkerCount(1)`，而在进程退出时，我们同样会调用`modifyWorkerCount(-1)`。

具体的通信过程实现见_通信协议_部分。为了简明，我们将不在此处给出具体实现。

## `ext2_evict`的实现

（假设我们已经作了必要的权限检查，并已经排除了所有的竞争情况，且我们可以独占文件）  
若要将磁盘上的文件发送到文件服务器，并将本地的磁盘块，页面缓存等清空，必须实现如下的几步操作：

1. 建立与云服务器的连接。  
2. 将文件读入内存，并将内存中的文件发送到云服务器（如有必要则分段）。  
3. 清空磁盘中文件占用的磁盘块与内存中的缓存页面等。  

我们分步考察这些步骤的实现。

### 建立与云服务器的连接

我们使用内核中的`socket`机制实现此步骤。  
实际的做法是在内核中调用sock_create_kern初始化`socket`结构，并调用`socket_operation`中的`connect`方法建立连接。  
具体的实现为`connect_cloud_host`方法。其代码如下：

```c
static int connect_cloud_host(
    const char *ip, unsigned short port, struct socket **socket)
{
    struct sockaddr_in address;
    int ret;

    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    address.sin_addr.s_addr = in_aton(ip);

    if (unlikely(
        (ret = sock_create_kern(AF_INET, SOCK_STREAM, 0, socket)) < 0))
    {
        return ret;
    }

    ret = (*socket)->ops->connect(
        (*socket), (struct sockaddr*)(&address), sizeof(address), 0);
    if (unlikely(ret != 0))
    {
        return ret > 0 ? -ret : ret;
    }

    return 0;
}
```

需要注意的是，这里传入的`socket`指针必须是传址调用的，否则返回后调用者得到的`socket`指针将不是合理的。

### 与云服务器通信

为了与云服务器通信，我们使用了`ktcp_recv`与`ktcp_send`方法。

```c
int ktcp_recv(struct socket *sock, unsigned char *buf, int len) 
{
	struct msghdr msg;
	struct iovec iov;
	mm_segment_t oldfs;
	int size = 0;
    int ite = 0;

	if (sock->sk == NULL) 
    {
        return 0;
    }

	oldfs = get_fs();
	set_fs(KERNEL_DS);

    while (ite < len)
    {
        int remain = len - ite;
        iov.iov_base = buf + ite;
        iov.iov_len = remain;

        msg.msg_control = NULL;
        msg.msg_controllen = 0;
        msg.msg_flags = 0;
        msg.msg_name = 0;
        msg.msg_namelen = 0;
        msg.msg_iov = &iov;
        msg.msg_iovlen = 1;

        size = sock_recvmsg(sock, &msg, remain, msg.msg_flags);
        ite += size;
    }
    set_fs(oldfs);

	return ite;
}

int ktcp_send(struct socket *sock,char *buf, int len) 
{
	struct msghdr msg;
	struct iovec iov;
	int size;
	mm_segment_t oldfs;

	iov.iov_base = buf;
	iov.iov_len = len;

	msg.msg_control = NULL;
	msg.msg_controllen = 0;
	msg.msg_flags = 0;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_name = 0;
	msg.msg_namelen = 0;

	oldfs = get_fs();
	set_fs(KERNEL_DS);
	size = sock_sendmsg(sock, &msg, len);
	set_fs(oldfs);

	return size;
}
```

注意到，我们在发送文件时，只需要使用一次发送操作即可。但在接收文件时则可能遇到不足值。我们无法用类似服务器中的事件机制来实现不足值的处理（因为不能修改用户注册的信号处理机制），于是我们需要用循环读取的方法来读取指定数量的字节。

另外一个要注意的方面是，`set_fs`操作。这个操作会对内核的地址检查机制进行修改，当我们调用`set_fs(KERNEL_DS)`后，本应接收用户空间指针的内核函数将可以接受来自内核空间的指针。这个操作非常重要，因为我们将要利用`read`/`open`/`write`等系统调用来实现余下的功能，而要让这些功能正常工作，这个操作是必须的。

### 由inode获取文件路径

在`ext2_evict`的执行流程中，我们需要执行一些文件I/O操作。为了实现这些操作，最朴素，同时也是充分利用了内核本身机制，防止了绝大部分bug出现的思想是利用open，read，write等系统调用。但为了利用这些系统调用，我们首先需要获得文件的路径。

为了实现这个目标，朴素的思想是，因为`inode`关联的`dentry`中有至少一个是有效的，这可以通过在`dentry`树中进行回溯来实现（从原理上看，这和`getcwd`系统调用非常相似，`getcwd`系统调用获取当前工作路径的原理也是从当前路径的`dentry`开始进行回溯）。但遗憾的是，我们最终并不能采用它。这是因为上述假设是错误的。`dentry`和`inode`的缓存机制使得`inode`本身的`dentry`，或者上层目录的`dentry`可能并不在内存中，这将导致执行失败。

典型地，我们在遍历文件系统并试图驱逐文件时，为了根据`i_ino`获取对应的`inode`，需要调用`ext2_iget`方法。而调用时这个`inode`对应的文件可能从未被访问过，也就是说`ext2_iget`会返回一个全新的`inode`，而我们无法回溯它关联的`dentry`树（因为还未被创建）。

为了实现一个传入任意普通文件的`inode`（实质上是传入任意普通文件的`inode`编号）就可以得到对应路径的函数，我们使用了如下的方法：

1. 考虑`super_block`的根`dentry`是永久存在于`dentry`树中的，我们可以用回溯的方法来获取`super_block`根的绝对路径。  
2. 对于磁盘中的普通文件，我们在创建它时保存一个名为`parent_ino`的`xattr`，这使得我们可以通过文件找到目录，而在找到目录后，我们遍历目录项以获得文件名称。
3. 在获得目录后，逐级回溯，并在上层目录中获得目录名称。
4. 回溯到根`dentry`后，将获取的所有名称连接以获得完整路径。

值得一提的是，这样获取的路径一定是合法的，因为`super_block`的路径一定是合法的，而在磁盘内回溯得到的文件路径也一定是合法的。

具体的实现为`get_filename_by_inode`方法。其代码如下：

```c
static int get_path_by_inode(struct inode *inode, char *buf, int buflen)
{
    char *ret;
    struct list_head *mnt_ite;
    struct path path;
    int pos;
    int x;
    struct inode *dir, *file;
    int ppos = buflen;

    list_for_each(mnt_ite, &(current->nsproxy->mnt_ns->list))
    {
        struct mount *mount = container_of(mnt_ite, struct mount, mnt_list);
        
        if (mount->mnt.mnt_sb->s_op->evict_fs != NULL)
        {
            path.mnt = &mount->mnt;
        }
    }

    path.dentry = inode->i_sb->s_root;
    if (unlikely(IS_ERR(ret = d_absolute_path(&path, buf, buflen))))
    {
        return -1;
    }

    pos = strlen(ret);
    memcpy(buf, ret, pos);

    ext2_xattr_get(inode, EXT2_XATTR_INDEX_TRUSTED, "parent_ino", &x, 4);

    file = ext2_iget(inode->i_sb, inode->i_ino);
    dir = ext2_iget(inode->i_sb, x);

    while (!is_root_inode(file))
    {
        struct ext2_dir_entry_2 *ed;
        struct page *page;

        ed = ext2_find_entry_ino(dir, file->i_ino, &page);
        buf[ppos -= (ed->name_len + 1)] = '/';
        memcpy(buf + ppos + 1, ed->name, ed->name_len);

        ext2_put_page(page);

        iput(file);
        file = dir;
        ed = ext2_dotdot(dir, &page);
        ext2_put_page(page);
        dir = ext2_iget(inode->i_sb, ed->inode);
    }

    for (; ppos < buflen; ++ppos)
    {
        buf[pos++] = buf[ppos];
    }
    buf[pos] = 0;

    iput(dir);
    iput(file);
    printk("path %s\n", buf);
    return 0;
}
```

首先，我们利用evictable_ext2的特性，找到我们的文件系统对应的`super_block`，再获取其绝对路径，之后进行如上所述的回溯。

而在这之中，为了利用inode编号找到目录项，我们实现了`ext2_find_entry_ino`方法。其代码如下：

```diff
diff --git a/fs/ext2/dir.c b/fs/ext2/dir.c
index 4237722bf..96f95d0 100644
--- a/fs/ext2/dir.c
+++ b/fs/ext2/dir.c
@@ -731,3 +731,65 @@ const struct file_operations ext2_dir_operations = {
 #endif
 	.fsync		= ext2_fsync,
 };
+
+struct ext2_dir_entry_2 *ext2_find_entry_ino (struct inode * dir,
+			ino_t ino, struct page ** res_page)
+{
+	unsigned long start, n;
+	unsigned long npages = dir_pages(dir);
+	struct page *page = NULL;
+	struct ext2_inode_info *ei = EXT2_I(dir);
+	ext2_dirent * de;
+	int dir_has_error = 0;
+
+	if (npages == 0)
+		goto out;
+
+	/* OFFSET_CACHE */
+	*res_page = NULL;
+
+	start = ei->i_dir_start_lookup;
+	if (start >= npages)
+		start = 0;
+	n = start;
+	do {
+		char *kaddr;
+		page = ext2_get_page(dir, n, dir_has_error);
+		if (!IS_ERR(page)) {
+			kaddr = page_address(page);
+			de = (ext2_dirent *) kaddr;
+			kaddr += ext2_last_byte(dir, n);
+			while ((char *) de <= kaddr) {
+				if (de->rec_len == 0) {
+					ext2_error(dir->i_sb, __func__,
+						"zero-length directory entry");
+					ext2_put_page(page);
+					goto out;
+				}
+				if (de->inode == ino)
+					goto found;
+				de = ext2_next_entry(de);
+			}
+			ext2_put_page(page);
+		} else
+			dir_has_error = 1;
+
+		if (++n >= npages)
+			n = 0;
+		/* next page is past the blocks we've got */
+		if (unlikely(n > (dir->i_blocks >> (PAGE_CACHE_SHIFT - 9)))) {
+			ext2_error(dir->i_sb, __func__,
+				"dir %lu size %lld exceeds block count %llu",
+				dir->i_ino, dir->i_size,
+				(unsigned long long)dir->i_blocks);
+			goto out;
+		}
+	} while (n != start);
+out:
+	return NULL;
+
+found:
+	*res_page = page;
+	ei->i_dir_start_lookup = n;
+	return de;
+}
```

这个函数实际上是参照`ext2_find_entry`实现的，即遍历过程相同，只是在匹配目录项信息时使用了`inode->i_ino`。

为了方便调用，我们对它进行了简单的包装，即`set_e_filename`/`set_f_filename`方法。

```c
static inline int set_e_filename(struct inode *inode)
{
    e_filename[0] = 0;
    return get_path_by_inode(inode, e_filename, PAGE_SIZE);
}

static inline int set_f_filename(struct inode *inode)
{
    f_filename[0] = 0;
    return get_path_by_inode(inode, f_filename, PAGE_SIZE);
}
```

### 将文件发送到云服务器

为了发送文件，我们首先使用VFS机制中实现的系统调用将文件读入内存。  
实际的做法是调用`open`与`read`系统调用将文件读入内存。  
而对于文件发送操作，我们利用之前获取的`socket`与已连接描述符与云服务器进行通信（通信协议如上所述）。  

实际的实现对应`send_file`函数，如下所示：

```c
static int send_file(char *filename, int inode_num, int size)
{
    int fd;
    struct socket *socket;
    int ret;

    socket = (struct socket*)kmalloc(sizeof(struct socket), GFP_KERNEL);

    if (unlikely(socket == NULL))
    {
        return -ENOMEM;
    }

    printk("socket alloc\n");
    if (unlikely((fd = sys_open(filename, O_RDONLY, 0777)) < 0))
    {
        ret = fd;
        goto no_connect_ret;
    }
 
    printk("open success\n");
    if (unlikely((ret = connect_cloud_host(cloud_ip, cloud_port, &socket)) < 0))
    {
        printk("fail %d\n", ret);
        ret = -ECONNABORTED;
        goto put_ret;
    }

    printk("host connected\n");
    if (unlikely((ret = do_send(fd, inode_num, size, socket)) < 0))
    {
        goto put_ret;
    }

    printk("file sended\n");
    ret = 0;

put_ret:
    sock_release(socket);
    goto out;
no_connect_ret:
    kfree(socket);
out:
    sys_close(fd);
    return ret;
}
```

注意到，此函数其实是发送操作的简单包装，它实际上是为了生成`do_send`方法所需的参数。

`do_send`方法的实现如下：

```c
static int do_send(int fd, int inode_num, int size, struct socket *socket)
{
    // send request
    sprint_int(e_buffer, CLFS_PUT);
    sprint_int(e_buffer + 4, inode_num);
    sprint_int(e_buffer + 8, size);
    if (unlikely(ktcp_send(socket, e_buffer, 12) < 12))
    {
        return -ECONNRESET;
    }
    printk("request sended\n");
    if (unlikely(get_reply(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("reply got\n");
     //see if the server is able to receive file... 
    if (unlikely(rep != 0))
    {
        return -ECONNRESET;
    }
    printk("ready to send block\n");

    while (size > BUFFER_SIZE)
    {
        if (unlikely(segmented_read(fd, e_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -EINVAL;
        }
        size -= BUFFER_SIZE;
        
        if (unlikely(ktcp_send(socket, e_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -ECONNRESET;
        }

        if (unlikely(get_reply(socket) < 0))
        {
            return -ECONNRESET;
        }
        printk("block sended\n");
    }
    if (unlikely(segmented_read(fd, e_buffer, size) < size))
    {
        return -EINVAL;
    }
    if (unlikely(ktcp_send(socket, e_buffer, size) < size))
    {
        return -ECONNRESET;
    }
    if (unlikely(get_reply(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("remain sended\n");

    return 0;
}
```

实际上，这个函数对应着_通信协议_部分约定的`put`操作流程。而我们也注意到，在这个函数中我们调用了`segmented_read`方法来读入文件。这是因为为了和POSIX标准兼容，`read`/`write`系统调用一次最多只能读写`#define SSIZE_MAX 32767`个字节。如果需要读取更多，则必须多次调用。而`segmented_read`的实现如下：

```c
static int segmented_read(int fd, void *buf, int len)
{
    int ite = 0;
    while (len > SSIZE_MAX)
    {
        int ret = sys_read(fd, buf + ite, SSIZE_MAX);
        //printk("segread: %d\n", ret);
        if (ret < SSIZE_MAX)
        {
            ite = ret < 0 ? ret : ite + ret;
            goto out;
        }
        len -= SSIZE_MAX;
        ite += SSIZE_MAX;
    }
    if (len != 0)
    {
        int ret = sys_read(fd, buf + ite, len);
        //printk("segread: %d\n", ret);
        ite = ret < 0 ? ret : ite + ret;
    }
out:
    printk("segread: ret %d\n", ite);
    return ite;
}
```

类似地，我们也实现了`segmented_write`方法（在之后将不再对此方法作出解释）。

### 清空磁盘中文件占用的磁盘块与内存中的缓存页面

为了腾出磁盘空间，我们需要清空文件占用的磁盘块，此处我们仍然利用VFS机制中实现的`open`系统调用：实际上只需要在系统调用中指定`O_TRUNC`标记位，那么打开文件时文件内容就会被自动清空。  
之后我们只需要关闭文件并强制系统将之写回磁盘。这可以利用`fsync`系统调用实现。  
而我们需要注意到，我们必然是当前打开文件的最后一个用户，所以只要关闭文件，系统就会调用`file_operations`中的`release`方法，从而释放缓存页面，即这个过程不需要我们手动干涉。  
具体的实现为`evict_ondisk_file`方法。其代码如下：

```c
static int evict_ondisk_file(char *filename)
{
    int error;
    if (unlikely((error = sys_open(filename, O_WRONLY | O_TRUNC, 0777)) < 0))
    {
        return error;
    }
    if (unlikely((error = sys_close(error)) < 0))
    {
        return error;
    }

    return 0;
}
```

### 维护文件元数据

由于在实现过程中我们用到了`open`等系统调用，也就是说，上述流程会更改文件元数据。所以我们需要在开始操作前对文件元数据进行备份，并在完成操作后将元数据写回。我们主要关注的元数据有：

1. 文件大小相关：`i_size`、`i_bytes`
2. 文件占用的块数量相关：`i_blkbits`、`i_blocks`
3. 时间戳：`i_atime`、`i_mtime`、`i_ctime`

我们主要在文件操作开始时执行`save_file_metadata`方法以存储元数据，在结束时执行`put_file_metadata`方法以将元数据写回`inode`。
上述两个函数的代码如下：

```c
static inline int save_inode_metadata(struct inode *inode)
{
    i_size = inode->i_size;
    i_atime = inode->i_atime;
    i_mtime = inode->i_mtime;
    i_ctime = inode->i_ctime;
    i_blkbits = inode->i_blkbits;
    i_blocks = inode->i_blocks;
    i_bytes = inode->i_bytes;
    dirtied_when = inode->dirtied_when;

    return 0;
}

static inline int put_inode_metadata(struct inode *inode)
{
    inode->i_size = i_size;
    inode->i_atime = i_atime;
    inode->i_mtime = i_mtime;
    inode->i_ctime = i_ctime;
    inode->i_blkbits = i_blkbits;
    inode->i_blocks = i_blocks;
    inode->i_bytes = i_bytes;
    inode->dirtied_when  = dirtied_when;

    return sync_inode_metadata(inode, 1);
}
```

注意到，我们使用了`sync_inode_metadata`以强制系统将元数据写回，并指定了它的第二个参数为1以等待它结束。

### 具体的`ext2_evict`

我们先来看`do_ext2_evict`方法：

```c
static int do_ext2_evict(struct inode *inode)
{
    int evicted;
    int error;

    printk("evicting\n");

    if (unlikely((error = set_e_filename(inode)) < 0))
    {
        return error;
    }

    if (unlikely((error = lock_inode(inode)) < 0))
    {
        return error;
    }

    save_inode_metadata(inode);

    //printk("meta saved\n");

    if (unlikely((error = send_file(
        e_filename, inode->i_ino, inode->i_size)) < 0))
    {
        return error;
    }

    printk("file sended\n");

    if (unlikely((error = evict_ondisk_file(e_filename)) < 0))
    {
        return error;
    }

    evicted = 1;
    if (unlikely((error = ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
        "evicted", &evicted, 4, XATTR_REPLACE)) < 0))
    {
        int value = 1;
        if ((error = (ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
            "evicted", &value, 4, XATTR_CREATE)) < 0))
        {
            return error;
        }
    }

    //printk("disk released\n");

    if (unlikely((error = put_inode_metadata(inode) < 0)))
    {
        return error;
    }

    //printk("inode recovered\n");

    if (unlikely((error = unlock_inode(inode)) < 0))
    {
        return error;
    }
    return 0;
}
```

而为了排除竞争情况，我们在包装函数`ext2_evict`中进行了同步操作：

```c
int ext2_evict(struct inode *inode)
{
    mm_segment_t oldfs;
    unsigned long ret = 0;
    int evicted;

    if (is_inode_inuse(inode))
    {
        printk("evict: inuse\n");
        return -EINVAL;
    }

    evicted = check_file_xattr_evict(inode);

    printk("xattr_evict %d\n", evicted);
    if (evicted < 0)
    {
        return evicted;
    }
    else if (evicted == 1)
    {
        return 0;
    }

    check_evict_mutex();
    mutex_lock(&evict_mutex);
    
	oldfs = get_fs();
	set_fs(KERNEL_DS);
    ret = do_ext2_evict(inode);
    set_fs(oldfs);

    mutex_unlock(&evict_mutex);

    printk("evict: %lu\n", ret);
    return ret;
}
```

如上所示，我们在进入`do_ext2_evict`主流程之前，执行了`set_fs`与加锁操作。这使得我们排除了竞争情况，也可以互斥访问共享数据。相对的，我们也有一个`ext2_evict_with_prev_lock`方法，这个方法在进入`do_ext2_evict`之前不会进行加锁。

而我们检查`inode`是否正被使用的`is_inode_inuse`方法的实现如下：

```c
static int is_inode_inuse(struct inode *inode)
{
    struct hlist_node *ite = (inode->i_dentry).first;
    while (ite != NULL)
    {
        struct dentry *dentry = container_of(ite, struct dentry, d_alias);

        spin_lock(&dentry->d_lock);
        if (dentry->d_count != 0)
        {
            printk("inuse\n");
            return 1;
        }
        spin_unlock(&dentry->d_lock);

        ite = ite->next;
    }
    return 0;
}
```

实质上，这个方法遍历了`inode`关联的`dentry`，并用`dentry`的被引用情况来判断`inode`是否正被使用。

## `ext2_fetch`的实现

在`ext2_evict`的实现中所用到的工具方法的基础上，我们可以很容易地实现`ext2_fetch`方法。实际上，我们仍能得出如下的主要流程（仍做出类似于之前的假定）：

1. 备份文件元数据。
2. 建立与云服务器的连接。
3. 从云服务器读取信息，并将之写入文件（如有必要则分段）。
4. 将文件元数据写回。

上述步骤中的1、2、4三步的实现与上一个部分相同，此处不再赘述。

### 从云服务器读取信息并写入文件

与读取相对应的，对于文件写入操作，我们使用`write`系统调用来完成。  
而为了从云服务器读取信息，我们仍然需要使用从`connect_cloud_host`方法中获取的`socket`。
具体的实现为`receive_file`方法。其代码如下：

```c
static int receive_file(char *filename, int inode_num)
{
    int fd;
    struct socket *socket;
    int ret;

    socket = (struct socket*)kmalloc(sizeof(struct socket), GFP_KERNEL);

    if (unlikely(socket == NULL))
    {
        return -ENOMEM;
    }

    printk("socket created\n");

    if (unlikely((fd = sys_open(filename, O_WRONLY | O_TRUNC, 0777)) < 0))
    {
        ret = fd;
        printk("fd %d\n", fd);
        goto no_connect_ret;
    }

    printk("file opened\n");
 
    if (unlikely((ret = connect_cloud_host(cloud_ip, cloud_port, &socket)) < 0))
    {
        ret = -ECONNABORTED;
        goto put_ret; 
    }

    printk("host connected\n");

    if (unlikely((ret = do_receive(fd, inode_num, socket)) < 0))
    {
        goto put_ret;
    }

    printk("file received\n");

    ret = 0;

put_ret:
    sock_release(socket);
    goto out;
no_connect_ret:
    kfree(socket);
out:
    sys_close(fd);
    return ret;
}
```

与`send_file`类似地，这个函数也只是为了生成`do_receive`所需的参数。实际的`do_receive`方法如下：

```c
static int do_receive(int fd, int inode_num, struct socket *socket)
{
    int size;

    // send request
    sprint_int(f_buffer, CLFS_GET);
    sprint_int(f_buffer + 4, inode_num);
    if (unlikely(ktcp_send(socket, f_buffer, 12) < 12))
    {
        return -ECONNRESET;
    }
    printk("request sent\n");
    if (unlikely(get_reply(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("got reply\n");

    if (unlikely(ktcp_recv(socket, f_buffer, 4) < 4))
    {
        return -ECONNRESET;
    }
    if (unlikely(reply_byte(socket) < 0))
    {
        return -ECONNRESET;
    }
    size = *(f_buffer + 3) + (((int)(*(f_buffer + 2))) << 8) + 
        (((int)(*(f_buffer + 1))) << 16) + (((int)(*f_buffer)) << 24);
    if (unlikely(size < 0))
    {
        return -EINVAL;
    }

    printk("size: %d\n", size);

    while (size > BUFFER_SIZE)
    {
        if (unlikely(ktcp_recv(socket, f_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -ECONNRESET;
        }
        printk("message received\n");

        size -= BUFFER_SIZE;
        if (unlikely(segmented_write(fd, f_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -ECONNRESET;
        }

        if (unlikely(reply_byte(socket) < 0))
        {
            return -ECONNRESET;
        }
        printk("block received\n");
    }
    if (unlikely(ktcp_recv(socket, f_buffer, size) < size))
    {
        return -ECONNRESET;
    }
    printk("message received\n");
    if (unlikely(segmented_write(fd, f_buffer, size) < size))
    {
        return -ECONNRESET;
    }
    if (unlikely(reply_byte(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("remain received\n");

    return 0;
}
```

这实际上是`put`操作的对应通信协议的简单实现。

### 实际的`ext2_fetch`

类似`ext2_evict`的实现结构，`do_ext2_fetch`操作的代码如下：

```c
static int do_ext2_fetch(struct inode *inode)
{
    int evicted;
    int error;

    if (unlikely(error = lock_inode(inode)) < 0)
    {
        return error;
    }

    //printk("inode locked\n");

    if (unlikely((error = set_f_filename(inode)) < 0))
    {
        return error;
    }
    
    //printk("got path\n");

    save_inode_metadata(inode);

    if (unlikely((error = receive_file(f_filename, inode->i_ino)) < 0))
    {
        return error;
    }

    //printk("file received\n");

    evicted = 0;
    if (unlikely((error = ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
        "evicted", &evicted, 4, XATTR_REPLACE)) < 0))
    {
        int value = 0;
        if ((error = (ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
            "evicted", &value, 4, XATTR_CREATE)) < 0))
        {
            return error;
        }
    }

    //printk("xattr set\n");

    if (unlikely((error = put_inode_metadata(inode) < 0)))
    {
        return error;
    }

    //printk("inode recovered\n");

    if (unlikely((error = unlock_inode(inode)) < 0))
    {
        return error;
    }

    return 0;
}
```

而在包装此函数时，我们需要考虑一些其他的问题。我们注意到，在open系统调用中，如果发现文件需要取回，则会调用`ext2_fetch`函数。而在fetch执行过程中，我们会需要打开文件以进行写入。这会造成无限循环。而且，因为加锁的缘故，它首先会引发死锁。另外，在fetch的过程中，我们需要使用磁盘块。这可能会触发evict操作。所以fetch和evict操作不能共享一个互斥锁，否则也会引发死锁。于是我们实现这个函数的方式如下：

```c
int ext2_fetch(struct inode *inode)
{
    static struct task_struct *task = NULL;
    unsigned long ret = 0;
    mm_segment_t oldfs;
    int evicted;

    //printk("task %lx, in_fetch %d\n", (unsigned long)task, in_fetch);

    if (task == current)
    {
        //printk("to avoid deadlock...\n");
        return 23333;
    }

    evicted = check_file_xattr_evict(inode);
    if (evicted < 0)
    {
        return evicted;
    }
    else if (evicted == 0)
    {
        return 0;
    }

    check_fetch_mutex();
    mutex_lock(&fetch_mutex);

	oldfs = get_fs();
	set_fs(KERNEL_DS);
    task = current;
    ret = do_ext2_fetch(inode);
    task = NULL;
    set_fs(oldfs);

    mutex_unlock(&fetch_mutex);
    
    printk("fetch: %lu\n", ret);
    return ret;
}
```

实际的操作是，如果fetch被同一进程连续调用（因为互斥锁，如果有进程在上一次fetch退出之前就再次调用了fetch，一定是因为触发了open中的fetch操作），我们就直接返回一个特殊值。

### 在打开文件时调用fetch

如上所述，为了防止重复调用，我们需要在open时进行一些特殊处理。

```c
void ext2_fetch_waiting(void)
{
    struct inode *inode = ext2_iget(sb, ino_to_fetch);

    printk("wait inode %lx\n", (unsigned long)inode);

    check_evict(inode);

    printk("in_fetch set!\n");
    in_fetch = 1;
    ext2_fetch(inode);
    in_fetch = 0;
    printk("in_fetch reset!\n");

    iput(inode);
}
EXPORT_SYMBOL(ext2_fetch_waiting);

int evictable_ext2_file_open(struct inode *inode, struct file *file)
{
    int evicted;
    printk("open with in_fetch=%d\n", in_fetch);

    if (!in_fetch)
    {
        evicted = check_file_xattr_evict(inode);
        if (evicted != 0)
        {
            printk("activate 23333 mode\n");
            ino_to_fetch = inode->i_ino;
            sb = inode->i_sb;
            return -ECONNRESET;
        }
    }
    else
    {
        printk("bypass!\n");
    }

    return dquot_file_open(inode, file);
}
```

实际上，我们注册的打开文件函数是`evictable_ext2_file_open`，如果再打开文件时发现文件已经被驱逐，则会返回一个特殊的错误码，并保存`i_ino`编号和`super_block`。之后我们修改`sys_open`，使之在接收到此错误码时调用`ext2_fetch_waiting`取回文件，并在之后重新启动open系统调用打开文件。在这里，我们在open包装函数的最外层才判断返回值，这是因为如果不在此处使用，则会因为inode已经被锁定而导致操作失败。

而为了防止重复调用，我们在`ext2_fetch_waiting`中设置一标志值，以表示当前正在取回文件，而`evictable_ext2_file_open`接收到此标志值时则会默许文件打开。

（check_evict）的具体实现会在之后说明。

## 监视文件系统

### 绕过`SELinux`保护机制

为了监视文件系统，我们要创建内核线程，并确定其工作流程。朴素的思想是每次休眠60秒，之后找到支持`evict_fs`的`super_block`，对其进行evict操作。但这会遇到问题。因为（未知原因），内核线程进行文件读写时会被`SELinux`安全子系统判定为无权限执行操作（虽然直观上显然是荒谬的）。所以我们必须首先找到绕过保护机制的方法。我们注意到，如果将`SELinux`的执行模式从`enforce`调整到`permissive`，则当它权限检查失败时，会默许程序的操作，而仅仅只给出一条警告信息。我们找到了内核中对应的设置函数`sel_write_enforce`，并实现了包装函数`sel_write_enforce_val`以供使用。代码如下：

```diff
diff --git a/security/selinux/selinuxfs.c b/security/selinux/selinuxfs.c
index ff42773..dee64c0 100644
--- a/security/selinux/selinuxfs.c
+++ b/security/selinux/selinuxfs.c
@@ -137,6 +137,25 @@ static ssize_t sel_read_enforce(struct file *filp, char __user *buf,
 }
 
 #ifdef CONFIG_SECURITY_SELINUX_DEVELOP
+
+ssize_t sel_write_enforce_val(int new_value)
+{
+	if (new_value != selinux_enforcing) {
+		audit_log(current->audit_context, GFP_KERNEL, AUDIT_MAC_STATUS,
+			"enforcing=%d old_enforcing=%d auid=%u ses=%u",
+			new_value, selinux_enforcing,
+			from_kuid(&init_user_ns, audit_get_loginuid(current)),
+			audit_get_sessionid(current));
+		selinux_enforcing = new_value;
+		if (selinux_enforcing)
+			avc_ss_reset(0);
+		selnl_notify_setenforce(selinux_enforcing);
+		selinux_status_update_setenforce(selinux_enforcing);
+	}
+	return 0;
+}
+EXPORT_SYMBOL(sel_write_enforce_val);
+
 static ssize_t sel_write_enforce(struct file *file, const char __user *buf,
 				 size_t count, loff_t *ppos)
```

由此，我们便可以进行实际的文件操作了。

### 实现时钟算法

为了实现时钟算法，我们首先要实现遍历`inode`列表的方法。具体的实现是`for_each_inode`函数：

```diff
diff --git a/fs/ext2/ialloc.c b/fs/ext2/ialloc.c
index 7cadd82..854afd6 100644
--- a/fs/ext2/ialloc.c
+++ b/fs/ext2/ialloc.c
@@ -673,3 +673,59 @@ unsigned long ext2_count_dirs (struct super_block * sb)
 	return count;
 }
 
+void for_each_inode(
+	struct super_block *super, void (*fun)(struct inode*, void*), void *arg)
+{
+	// - how to iterate over the fs ?
+    // - maybe the combine of read_inode_bitmap and ext2_iget works
+	struct ext2_sb_info *sbi = EXT2_SB(super);
+	struct ext2_super_block *es = sbi->s_es;
+	struct buffer_head *bh;
+
+    int group_count = sbi->s_groups_count; // ?
+    int i = 0;
+
+    for (; i < group_count; ++i)
+    {
+        int j = 0;
+        bh = read_inode_bitmap(super, i);
+
+        for (; j < bh->b_size; ++j)
+        {
+	        struct inode *inode;
+            unsigned char x = *((unsigned char*)bh->b_data + j);
+            int k = 0;
+            int ino = (j << 3) + 1;
+			unsigned char mask = 0x1;
+
+			//printk("bitmap: %x base: %d\n", x, ino);
+
+			for (; k < 8; ++k, ++ino, mask <<= 1)
+			{
+				if (unlikely(ino <= 10))
+				{
+					continue;
+				}
+				if (unlikely(ino > es->s_inodes_count))
+				{
+					brelse(bh);
+					goto out;
+				}
+				if (x & mask)
+				{
+					inode = ext2_iget(super, ino);
+					if (!IS_ERR(inode) && (inode != NULL))
+					{
+						printk("inode %lx, ino %d\n", (unsigned long)inode, ino);
+						fun(inode, arg);
+						iput(inode);
+					}
+				}
+			}
+        }
+		brelse(bh);
+    }
+out:
+	return;
+}
+EXPORT_SYMBOL(for_each_inode);
```

我们利用了`read_inode_bitmap`和`ext2_iget`函数来实现遍历。实际上对于每个`group`，我们可以通过空闲位图找到其中所有已使用的`inode`（这是一个蒙特卡洛型算法，很多inode的空闲位会被抹掉，但对它们调用`ext2_iget`会返回错误，所以我们仍然要进行错误检查）。而我们注意到，前十个`inode`是文件系统保留的，所以我们在搜索时要跳过它们。

在这个基础上，我们就可以进行扫描文件系统的操作了。在判定是否要进行驱逐时，我们希望能获得当前的磁盘使用率。这对应我们的`fs_filled`函数，如下所示：

```diff
diff --git a/fs/ext2/ext2.h b/fs/ext2/ext2.h
index d9a17d0..ecf879c 100644
--- a/fs/ext2/ext2.h
+++ b/fs/ext2/ext2.h
@@ -812,3 +832,18 @@ ext2_group_first_block_no(struct super_block *sb, unsigned long group_no)
 #define ext2_test_bit	test_bit_le
 #define ext2_find_first_zero_bit	find_first_zero_bit_le
 #define ext2_find_next_zero_bit		find_next_zero_bit_le
+
+
+static inline int fs_filled(struct super_block *sb)
+{
+    struct ext2_sb_info *sbi = EXT2_SB(sb);
+    struct ext2_super_block *es = sbi->s_es;
+
+    unsigned long total = es->s_blocks_count;// - es->s_r_blocks_count;
+    unsigned long used = total - ext2_count_free_blocks(sb);
+
+	//printk("total %lu, used %lu\n", total, used);
+
+    return (100 * (used)) / total;
+    //return 0;
+}
```

于是我们可以在`kfs_evictd`进入工作流程时首先利用此方法判定是否需要进行驱逐操作，之后才进行实际的驱逐。对于我们将要实现的驱逐方法，我们需要考虑两方面的需求，一方面是守护线程的驱逐操作，一方面则是fetch操作进行中可能触发的evict。前者的实现是简单的，但后者则需要考虑fetch时对磁盘块的使用。我们注意到在超过`high_watermark`之后，系统中的每一次写和每一次分配块都会引发evict操作。这实质上控制了磁盘使用率不能超过`high_watermark`。有很多方法能实现此目标，而在多处引发evict势必会增加出错的可能。我们选择不使用此实现方式，而是转而在fetch时预先判断文件的块需求，首先进行evict，腾出足够的空间之后再进行fetch，并且，我们在fetch时会阻塞文件操作，防止块被其他进程占用。于是，我们需要在evict实际进行时确定`evict_target`。具体的实现如下：

```c
void ext2_evict_void(struct inode *inode, void *arg)
{
    int value;
    int turn = *((int*)arg) / 100;
    int target = *((int*)arg) % 100;

    if (turn == 0 && inode->i_ino < clockhand)
    {
        return;
    }

    if (is_inode_inuse(inode))
    {
        return;
    }

    if (fs_filled(inode->i_sb) <= target)
    {
        return;
    }

    // we don't mean to evict directories.
    if (ext2_xattr_get(inode, EXT2_XATTR_INDEX_TRUSTED, "parent_ino", 
        &value, 4) < 0)
    {
        return;
    }
    else
    {
        unsigned long scan_time;
        unsigned long access_time; 
        printk("regular file\n");
        scan_time = check_file_xattr_scantime(inode);
        access_time = inode->i_atime.tv_sec;

        if (access_time > scan_time)
        {
            ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, "scantime", 
                &access_time, 8, XATTR_REPLACE);
        }
        else
        {
            printk("should evict\n");
            ext2_evict_with_prev_lock(inode);
            clockhand = inode->i_ino;
        }

    }
}

int ext2_evict_fs_until(struct super_block *super, int target)
{
    int arg = target;
    struct inode *inode = super->s_root->d_inode;

    check_evict_mutex();
    mutex_lock(&evict_mutex);

    clockhand = check_file_xattr_clockhand(inode);

    printk("clockhand: %lu\n", clockhand);

    if (fs_filled(inode->i_sb) > target)
    {
        for_each_inode(super, ext2_evict_void, &arg);
    }

    printk("turn 2\n");
    arg = target + 100;
    if (fs_filled(inode->i_sb) > target)
    {
        for_each_inode(super, ext2_evict_void, &arg);
    }
    printk("turn 3\n");
    if (fs_filled(inode->i_sb) > target)
    {
        for_each_inode(super, ext2_evict_void, &arg);
    }

    ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, "clockhand", 
        &clockhand, 8, XATTR_REPLACE);


    mutex_unlock(&evict_mutex);
    printk("end evict process\n");
    return 0;
}

int ext2_evict_fs(struct super_block *super)
{
    return ext2_evict_fs_until(super, evict_target);
}
```

为了实现时钟算法，我们只需要遍历`inode`最多三次。第一次的后半和第二次的前半会清除R标记，而第二次的后半和第三次的前半一定会将需要evict的所有`inode`都驱逐到服务器（因为它们都不会有R标记），而为了在第一次扫描时跳过`clockhand`之前的`inode`，我们在`ext2_evict_void`进行了一些特殊处理，如上所示。

注意到，我们在进入`ext2_evict_fs_until`时进行了加锁。这是因为`evict_evict_void`函数在执行时要求独占inode，否则互斥访问将导致死锁。

在以上的几个函数的基础上，我们将可以讨论`check_evict`的实现。

```c
static void check_evict(struct inode *inode)
{
    struct ext2_sb_info *sbi = EXT2_SB(sb);
    struct ext2_super_block *es = sbi->s_es;

    unsigned long total = es->s_blocks_count;

    unsigned long reserve = total - (total * high_watermark) / 100;
    unsigned long need = inode->i_size / sb->s_blocksize;
    unsigned long used = total - ext2_count_free_blocks(sb);

    printk("total %lu, reserve %lu, used %lu, need %lu\n", 
        total, reserve, used, need);

    if (used + need + reserve >= total)
    {
        unsigned long target = (100 * (total - reserve - need)) / total;

        target = target < evict_target ? target : evict_target;
        printk("need evict\n");
        ext2_evict_fs_until(sb, target);
    }
}
```

实际上是保证驱逐操作将磁盘使用率降到evict_target以下，并将将要取回的文件所要占用的磁盘块留出。

### 实际的`kfs_evictd`

实际的`kfs_evictd`相关代码如下：

```c
static void try_evict(struct super_block *super, void *data)
{
	if (super->s_op->evict_fs != NULL)
	{
		int filled = fs_filled(super);
		if (filled > low_watermark)
		{
			super->s_op->evict_fs(super);
		}
	}
}

static int evictd_main(void *data)
{
	do
	{
		printk("evictd: awaken\n");
		sel_write_enforce_val(0);
		iterate_supers(try_evict, NULL);
		printk("evictd: sleeping\n\n");

		ssleep(60);
	}
	while (!kthread_should_stop());

	return 0;
}

static int __init evictd_init(void)
{
    evictd_task = kthread_run(evictd_main, NULL, "kfs_evictd");

	return 0;
}
fs_initcall(evictd_init);
```

## 支持mount选项

我们注意到，ext2文件系统的mount操作函数是`ext2_mount`，于是我们将修改此函数以支持mount选项。

```diff
diff --git a/fs/ext2/super.c b/fs/ext2/super.c
index bc47f47..d00da10 100644
--- a/fs/ext2/super.c
+++ b/fs/ext2/super.c
@@ -317,6 +317,7 @@ static const struct super_operations ext2_sops = {
 	.statfs		= ext2_statfs,
 	.remount_fs	= ext2_remount,
 	.show_options	= ext2_show_options,
+	.evict_fs = ext2_evict_fs,
 #ifdef CONFIG_QUOTA
 	.quota_read	= ext2_quota_read,
 	.quota_write	= ext2_quota_write,
@@ -390,8 +391,8 @@ static unsigned long get_sb_block(void **data)
 }
 
 enum {
-	Opt_bsd_df, Opt_minix_df, Opt_grpid, Opt_nogrpid,
-	Opt_resgid, Opt_resuid, Opt_sb, Opt_err_cont, Opt_err_panic,
+	Opt_server, Opt_wh, Opt_wl, Opt_evict, Opt_bsd_df, Opt_minix_df, Opt_grpid, 
+	Opt_nogrpid, Opt_resgid, Opt_resuid, Opt_sb, Opt_err_cont, Opt_err_panic,
 	Opt_err_ro, Opt_nouid32, Opt_nocheck, Opt_debug,
 	Opt_oldalloc, Opt_orlov, Opt_nobh, Opt_user_xattr, Opt_nouser_xattr,
 	Opt_acl, Opt_noacl, Opt_xip, Opt_ignore, Opt_err, Opt_quota,
@@ -399,6 +400,10 @@ enum {
 };
 
 static const match_table_t tokens = {
+	{Opt_server, "srv=%u.%u.%u.%u:%u"},
+	{Opt_wh, "wh=%u"},
+	{Opt_wl, "wl=%u"},
+	{Opt_evict, "evict=%u"},
 	{Opt_bsd_df, "bsddf"},
 	{Opt_minix_df, "minixdf"},
 	{Opt_grpid, "grpid"},
@@ -451,6 +456,11 @@ static int parse_options(char *options, struct super_block *sb)
 
 		token = match_token(p, tokens, args);
 		switch (token) {
+		case Opt_server:
+		case Opt_wh:
+		case Opt_wl:
+	 	case Opt_evict:
+		 	break;
 		case Opt_bsd_df:
 			clear_opt (sbi->s_mount_opt, MINIX_DF);
 			break;
@@ -1423,7 +1433,13 @@ static int ext2_statfs (struct dentry * dentry, struct kstatfs * buf)
 static struct dentry *ext2_mount(struct file_system_type *fs_type,
 	int flags, const char *dev_name, void *data)
 {
-	return mount_bdev(fs_type, flags, dev_name, data, ext2_fill_super);
+	printk("data %s\n", (char*)data);
+	if (parse_evict_options(data) < 0)
+	{
+		return ERR_PTR(-EINVAL);
+	}
+
+	return mount_bdev(fs_type, flags, dev_name, NULL, ext2_fill_super);
 }
```

实际上，我们支持了一些mount的token，并使其在parse_options中进行处理。这是为了在remount进行时不会因为没有指定服务器等而出错。

而对于实际的mount操作，我们在调用系统的`mount_bdev`之前，首先调用了`parse_evict_options`对我们的选项进行处理。实际的`parse_evict_options`是朴素的字串处理函数，这个函数保证参数的合法性，并在参数不合法（序关系出错，ip不合法等）时返回-1。实际的实现没有太多的技术含量，也相当冗长（因为需要实现很多字符串处理的辅助函数），此处将不列出（定义于`ext2_evict.c`）。

## 存在的问题

本实现至少存在以下问题：

1. 对并发情况的互斥操作会导致性能大幅下降，且现有的并发处理并不能涵盖所有的情况（如要运行，建议注释掉balloc.c中的evict操作调用，因为在罕见的情况下它会和write中的evict操作冲突，但原因未知）
2. 网络通信效率低（大约只有800KB/s）
3. mount的支持并不完全（比如没有考虑remount） 
4. 并没有将evict和fetch实现成系统调用（因为我认为系统调用应当是提供给用户的接口，而用户不可能拥有合理的inode对象，于是将之包装成系统调用是完全多余的）