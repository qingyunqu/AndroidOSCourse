
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/backing-dev.h>
#include <linux/mm.h>
#include <linux/capability.h>
#include <linux/mman.h>
#include <linux/mm_types.h>
#include <linux/shm.h>
#include <linux/mman.h>
#include <linux/pagemap.h>
#include <linux/swap.h>
#include <linux/syscalls.h>
#include <linux/capability.h>
#include <linux/init.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <linux/personality.h>
#include <linux/security.h>
#include <linux/hugetlb.h>
#include <linux/profile.h>
#include <linux/export.h>
#include "../mount.h"
#include <linux/mempolicy.h>
#include <linux/rmap.h>
#include <linux/mmu_notifier.h>
#include <linux/perf_event.h>
#include <linux/audit.h>
#include <linux/khugepaged.h>
#include <linux/uprobes.h>
#include <linux/rbtree_augmented.h>
#include <linux/sched/sysctl.h>
#include <linux/notifier.h>
#include <linux/memory.h>

#include <linux/socket.h>
#include <linux/file.h>
#include <linux/net.h>
#include <linux/interrupt.h>
#include <linux/thread_info.h>
#include <linux/rcupdate.h>
#include <linux/netdevice.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/mutex.h>
#include <linux/if_bridge.h>
#include <linux/if_frad.h>
#include <linux/if_vlan.h>
#include <linux/poll.h>
#include <linux/cache.h>
#include <linux/module.h>
#include <linux/highmem.h>
#include <linux/compat.h>
#include <linux/kmod.h>
#include <linux/wireless.h>
#include <linux/nsproxy.h>
#include <linux/magic.h>
#include <linux/xattr.h>

#include <asm/unistd.h>

#include <net/compat.h>
#include <net/wext.h>
#include <net/cls_cgroup.h>

//#include <net/socket.h>
#include <linux/netfilter.h>

#include <linux/if_tun.h>
#include <linux/ipv6_route.h>
#include <linux/route.h>
#include <linux/sockios.h>
#include <linux/atalk.h>
#include <asm/uaccess.h>
#include <asm/cacheflush.h>
#include <asm/tlb.h>
#include <asm/mmu_context.h>
#include "ext2.h"
#include "xattr.h"
#include "acl.h"
#include <linux/in.h>  
#include <linux/inet.h>
#include <linux/delay.h>
#include <linux/init.h>  
#include <linux/module.h>
#include <linux/quotaops.h>
#include <linux/kthread.h>

struct task_struct *evictd_task;

extern ssize_t sel_write_enforce_val(int new_value);

static void try_evict(struct super_block *super, void *data)
{
	if (super->s_op->evict_fs != NULL)
	{
		int filled = fs_filled(super);
		if (filled > low_watermark)
		{
			super->s_op->evict_fs(super);
		}
	}
}

static int evictd_main(void *data)
{
	do
	{
		printk("evictd: awaken\n");
		sel_write_enforce_val(0);
		iterate_supers(try_evict, NULL);
		printk("evictd: sleeping\n\n");

		ssleep(60);
	}
	while (!kthread_should_stop());

	return 0;
}

static int __init evictd_init(void)
{
    evictd_task = kthread_run(evictd_main, NULL, "kfs_evictd");

	return 0;
}
fs_initcall(evictd_init);