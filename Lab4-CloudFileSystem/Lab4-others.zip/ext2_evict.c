#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/backing-dev.h>
#include <linux/mm.h>
#include <linux/capability.h>
#include <linux/mman.h>
#include <linux/mm_types.h>
#include <linux/shm.h>
#include <linux/mman.h>
#include <linux/pagemap.h>
#include <linux/swap.h>
#include <linux/sched.h>
#include <linux/syscalls.h>
#include <linux/capability.h>
#include <linux/init.h>
#include <linux/file.h>
#include <linux/fs.h>
#include <linux/personality.h>
#include <linux/security.h>
#include <linux/hugetlb.h>
#include <linux/profile.h>
#include <linux/export.h>
#include "../mount.h"
#include <linux/mempolicy.h>
#include <linux/rmap.h>
#include <linux/mmu_notifier.h>
#include <linux/perf_event.h>
#include <linux/audit.h>
#include <linux/khugepaged.h>
#include <linux/uprobes.h>
#include <linux/rbtree_augmented.h>
#include <linux/sched/sysctl.h>
#include <linux/notifier.h>
#include <linux/memory.h>

#include <linux/socket.h>
#include <linux/file.h>
#include <linux/net.h>
#include <linux/interrupt.h>
#include <linux/thread_info.h>
#include <linux/rcupdate.h>
#include <linux/netdevice.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/mutex.h>
#include <linux/if_bridge.h>
#include <linux/if_frad.h>
#include <linux/if_vlan.h>
#include <linux/poll.h>
#include <linux/cache.h>
#include <linux/module.h>
#include <linux/highmem.h>
#include <linux/compat.h>
#include <linux/kmod.h>
#include <linux/wireless.h>
#include <linux/nsproxy.h>
#include <linux/magic.h>
#include <linux/xattr.h>

#include <asm/unistd.h>

#include <net/compat.h>
#include <net/wext.h>
#include <net/cls_cgroup.h>

//#include <net/socket.h>
#include <linux/netfilter.h>

#include <linux/if_tun.h>
#include <linux/ipv6_route.h>
#include <linux/route.h>
#include <linux/sockios.h>
#include <linux/atalk.h>
#include <asm/uaccess.h>
#include <asm/cacheflush.h>
#include <asm/tlb.h>
#include <asm/mmu_context.h>
#include "ext2.h"
#include "xattr.h"
#include "acl.h"
#include <linux/in.h>  
#include <linux/inet.h>
#include <linux/delay.h>
#include <linux/init.h>  
#include <linux/module.h>
#include <linux/quotaops.h>

// request
#define CLFS_PUT 0
#define CLFS_GET 1
#define CLFS_RM 2
// response
#define CLFS_OK 0
#define CLFS_INVAL 22 // EINVAL
#define CLFS_ACCESS 13 // EACCES
#define CLFS_ERROR 131 // ECONNRESET
// buffer
#define SSIZE_MAX 32767
#define BUFFER_SIZE 65536

extern struct task_struct *evictd_task;
extern char *d_absolute_path(const struct path *path, char *buf, int buflen);
extern void for_each_inode(
	struct super_block *super, void (*fun)(struct inode*, void*), void *arg);
static inline void ext2_put_page(struct page *page)
{
	kunmap(page);
	page_cache_release(page);
}

char cloud_ip[32];
int cloud_port = 8888;
int high_watermark = 95;
int low_watermark = 85;
int evict_target = 70;

static struct mutex evict_mutex;
static char e_filename[PAGE_SIZE];
static char e_buffer[BUFFER_SIZE];

static struct mutex fetch_mutex;
static char f_filename[PAGE_SIZE];
static char f_buffer[BUFFER_SIZE];

static unsigned long clockhand;

static unsigned long ino_to_fetch;
static struct super_block *sb;
static int in_fetch = 0;

// @ktcp_recv contains modified code!
// originally from https://gist.github.com/llj098/752417
int ktcp_recv(struct socket *sock, unsigned char *buf, int len) 
{
	struct msghdr msg;
	struct iovec iov;
	mm_segment_t oldfs;
	int size = 0;
    int ite = 0;

	if (sock->sk == NULL) 
    {
        return 0;
    }

	oldfs = get_fs();
	set_fs(KERNEL_DS);

    while (ite < len)
    {
        int remain = len - ite;
        iov.iov_base = buf + ite;
        iov.iov_len = remain;

        msg.msg_control = NULL;
        msg.msg_controllen = 0;
        msg.msg_flags = 0;
        msg.msg_name = 0;
        msg.msg_namelen = 0;
        msg.msg_iov = &iov;
        msg.msg_iovlen = 1;

        size = sock_recvmsg(sock, &msg, remain, msg.msg_flags);
        ite += size;
    }
    set_fs(oldfs);
    printk("recv: message size is : %d\n", ite);

	return ite;
}
  
// @ktcp_send contains modified code!
// originally from https://gist.github.com/llj098/752417
int ktcp_send(struct socket *sock,char *buf, int len) 
{
	struct msghdr msg;
	struct iovec iov;
	int size;
	mm_segment_t oldfs;

	iov.iov_base = buf;
	iov.iov_len = len;

	msg.msg_control = NULL;
	msg.msg_controllen = 0;
	msg.msg_flags = 0;
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	msg.msg_name = 0;
	msg.msg_namelen = 0;

	oldfs = get_fs();
	set_fs(KERNEL_DS);
	size = sock_sendmsg(sock, &msg, len);
	set_fs(oldfs);
    //printk("send: message size: %d\n", size);

	return size;
}

// @connect_cloud_host contains modified code!
// originally from http://blog.csdn.net/adamska0104/article/details/44808741
static int connect_cloud_host(
    const char *ip, unsigned short port, struct socket **socket)
{
    struct sockaddr_in address;
    int ret;

    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    address.sin_addr.s_addr = in_aton(ip);

    if (unlikely(
        (ret = sock_create_kern(AF_INET, SOCK_STREAM, 0, socket)) < 0))
    {
        return ret;
    }

    ret = (*socket)->ops->connect(
        (*socket), (struct sockaddr*)(&address), sizeof(address), 0);
    if (unlikely(ret != 0))
    {
        return ret > 0 ? -ret : ret;
    }

    return 0;
}

void check_evict_mutex(void)
{
    static int first = true;
    if (unlikely(first))
    {
        first = false;
        mutex_init(&evict_mutex);
    }
}

void check_fetch_mutex(void)
{
    static int first = true;
    if (unlikely(first))
    {
        first = false;
        mutex_init(&fetch_mutex);
    }
}

static inline int is_root_inode(struct inode *inode)
{
    return inode->i_ino == 2;
}

static int get_path_by_inode(struct inode *inode, char *buf, int buflen)
{
    char *ret;
    struct list_head *mnt_ite;
    struct path path;
    int pos;
    int x;
    struct inode *dir, *file;
    int ppos = buflen;

    list_for_each(mnt_ite, &(current->nsproxy->mnt_ns->list))
    {
        struct mount *mount = container_of(mnt_ite, struct mount, mnt_list);
        
        if (mount->mnt.mnt_sb->s_op->evict_fs != NULL)
        {
            path.mnt = &mount->mnt;
        }
    }

    path.dentry = inode->i_sb->s_root;
    if (unlikely(IS_ERR(ret = d_absolute_path(&path, buf, buflen))))
    {
        return -1;
    }

    pos = strlen(ret);
    memcpy(buf, ret, pos);

    ext2_xattr_get(inode, EXT2_XATTR_INDEX_TRUSTED, "parent_ino", &x, 4);

    file = ext2_iget(inode->i_sb, inode->i_ino);
    dir = ext2_iget(inode->i_sb, x);

    while (!is_root_inode(file))
    {
        struct ext2_dir_entry_2 *ed;
        struct page *page;

        ed = ext2_find_entry_ino(dir, file->i_ino, &page);
        buf[ppos -= (ed->name_len + 1)] = '/';
        //ed->name[ed->name_len] = 0;
        memcpy(buf + ppos + 1, ed->name, ed->name_len);

        ext2_put_page(page);

        iput(file);
        file = dir;
        ed = ext2_dotdot(dir, &page);
        ext2_put_page(page);
        dir = ext2_iget(inode->i_sb, ed->inode);
    }

    for (; ppos < buflen; ++ppos)
    {
        buf[pos++] = buf[ppos];
    }
    buf[pos] = 0;

    iput(dir);
    iput(file);
    printk("path %s\n", buf);
    return 0;
}

/*
    get _one possible_ filename of inode, and store it in buffer.
    **: apply this to directories can cause panic!
*/
static inline int set_e_filename(struct inode *inode)
{
    e_filename[0] = 0;
    return get_path_by_inode(inode, e_filename, PAGE_SIZE);
}

static inline int set_f_filename(struct inode *inode)
{
    f_filename[0] = 0;
    return get_path_by_inode(inode, f_filename, PAGE_SIZE);
}

static inline void sprint_int(char *str, unsigned i)
{
    *(str + 3) = i & 0xFF;
    *(str + 2) = (i >> 8) & 0xFF;
    *(str + 1) = (i >> 16) & 0xFF;
    *str = (i >> 24) & 0xFF;
}

static char rep;

static inline int reply_byte(struct socket *socket)
{
    return ktcp_send(socket, &rep, 1);
}

static inline int get_reply(struct socket *socket)
{
    return ktcp_recv(socket, &rep, 1);
}

static int segmented_read(int fd, void *buf, int len)
{
    int ite = 0;
    while (len > SSIZE_MAX)
    {
        int ret = sys_read(fd, buf + ite, SSIZE_MAX);
        //printk("segread: %d\n", ret);
        if (ret < SSIZE_MAX)
        {
            ite = ret < 0 ? ret : ite + ret;
            goto out;
        }
        len -= SSIZE_MAX;
        ite += SSIZE_MAX;
    }
    if (len != 0)
    {
        int ret = sys_read(fd, buf + ite, len);
        //printk("segread: %d\n", ret);
        ite = ret < 0 ? ret : ite + ret;
    }
out:
    printk("segread: ret %d\n", ite);
    return ite;
}

static int segmented_write(int fd, void *buf, int len)
{
    int ite = 0;
    while (len > SSIZE_MAX)
    {
        int ret = sys_write(fd, buf + ite, SSIZE_MAX);
        //printk("segwrite: %d\n", ret);
        if (ret < SSIZE_MAX)
        {
            ite = ret < 0 ? ret : ite + ret;
            goto out;
        }
        len -= SSIZE_MAX;
        ite += SSIZE_MAX;
    }
    if (len != 0)
    {
        int ret = sys_write(fd, buf + ite, len);
        //printk("segwrite: %d\n", ret);
        ite = ret < 0 ? ret : ite + ret;
    }
out:
    printk("segwrite: ret %d\n", ite);
    return ite;
}

static int do_send(int fd, int inode_num, int size, struct socket *socket)
{
    // send request
    sprint_int(e_buffer, CLFS_PUT);
    sprint_int(e_buffer + 4, inode_num);
    sprint_int(e_buffer + 8, size);
    if (unlikely(ktcp_send(socket, e_buffer, 12) < 12))
    {
        return -ECONNRESET;
    }
    printk("request sended\n");
    if (unlikely(get_reply(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("reply got\n");
     //see if the server is able to receive file... 
    if (unlikely(rep != 0))
    {
        return -ECONNRESET;
    }
    printk("ready to send block\n");

    while (size > BUFFER_SIZE)
    {
        if (unlikely(segmented_read(fd, e_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -EINVAL;
        }
        size -= BUFFER_SIZE;
        
        if (unlikely(ktcp_send(socket, e_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -ECONNRESET;
        }

        if (unlikely(get_reply(socket) < 0))
        {
            return -ECONNRESET;
        }
        printk("block sended\n");
    }
    if (unlikely(segmented_read(fd, e_buffer, size) < size))
    {
        return -EINVAL;
    }
    if (unlikely(ktcp_send(socket, e_buffer, size) < size))
    {
        return -ECONNRESET;
    }
    if (unlikely(get_reply(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("remain sended\n");

    return 0;
}

static int send_file(char *filename, int inode_num, int size)
{
    int fd;
    struct socket *socket;
    int ret;

    socket = (struct socket*)kmalloc(sizeof(struct socket), GFP_KERNEL);

    if (unlikely(socket == NULL))
    {
        return -ENOMEM;
    }

    printk("socket alloc\n");
    if (unlikely((fd = sys_open(filename, O_RDONLY, 0777)) < 0))
    {
        ret = fd;
        goto no_connect_ret;
    }
 
    printk("open success\n");
    if (unlikely((ret = connect_cloud_host(cloud_ip, cloud_port, &socket)) < 0))
    {
        printk("fail %d\n", ret);
        ret = -ECONNABORTED;
        goto put_ret;
    }

    printk("host connected\n");
    if (unlikely((ret = do_send(fd, inode_num, size, socket)) < 0))
    {
        goto put_ret;
    }

    printk("file sended\n");
    ret = 0;

put_ret:
    sock_release(socket);
    goto out;
no_connect_ret:
    kfree(socket);
out:
    sys_close(fd);
    return ret;
}

static int do_receive(int fd, int inode_num, struct socket *socket)
{
    int size;

    // send request
    sprint_int(f_buffer, CLFS_GET);
    sprint_int(f_buffer + 4, inode_num);
    if (unlikely(ktcp_send(socket, f_buffer, 12) < 12))
    {
        return -ECONNRESET;
    }
    printk("request sent\n");
    if (unlikely(get_reply(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("got reply\n");

    if (unlikely(ktcp_recv(socket, f_buffer, 4) < 4))
    {
        return -ECONNRESET;
    }
    if (unlikely(reply_byte(socket) < 0))
    {
        return -ECONNRESET;
    }
    size = *(f_buffer + 3) + (((int)(*(f_buffer + 2))) << 8) + 
        (((int)(*(f_buffer + 1))) << 16) + (((int)(*f_buffer)) << 24);
    if (unlikely(size < 0))
    {
        return -EINVAL;
    }

    printk("size: %d\n", size);

    while (size > BUFFER_SIZE)
    {
        if (unlikely(ktcp_recv(socket, f_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -ECONNRESET;
        }
        printk("message received\n");

        size -= BUFFER_SIZE;
        if (unlikely(segmented_write(fd, f_buffer, BUFFER_SIZE) < BUFFER_SIZE))
        {
            return -ECONNRESET;
        }

        if (unlikely(reply_byte(socket) < 0))
        {
            return -ECONNRESET;
        }
        printk("block received\n");
    }
    if (unlikely(ktcp_recv(socket, f_buffer, size) < size))
    {
        return -ECONNRESET;
    }
    printk("message received\n");
    if (unlikely(segmented_write(fd, f_buffer, size) < size))
    {
        return -ECONNRESET;
    }
    if (unlikely(reply_byte(socket) < 0))
    {
        return -ECONNRESET;
    }
    printk("remain received\n");

    return 0;
}

static int receive_file(char *filename, int inode_num)
{
    int fd;
    struct socket *socket;
    int ret;

    socket = (struct socket*)kmalloc(sizeof(struct socket), GFP_KERNEL);

    if (unlikely(socket == NULL))
    {
        return -ENOMEM;
    }

    printk("socket created\n");

    if (unlikely((fd = sys_open(filename, O_WRONLY | O_TRUNC, 0777)) < 0))
    {
        ret = fd;
        printk("fd %d\n", fd);
        goto no_connect_ret;
    }

    printk("file opened\n");
 
    if (unlikely((ret = connect_cloud_host(cloud_ip, cloud_port, &socket)) < 0))
    {
        ret = -ECONNABORTED;
        goto put_ret; 
    }

    printk("host connected\n");

    if (unlikely((ret = do_receive(fd, inode_num, socket)) < 0))
    {
        goto put_ret;
    }

    printk("file received\n");

    ret = 0;

put_ret:
    sock_release(socket);
    goto out;
no_connect_ret:
    kfree(socket);
out:
    sys_close(fd);
    return ret;
}

static int evict_ondisk_file(char *filename)
{
    int error;
    if (unlikely((error = sys_open(filename, O_WRONLY | O_TRUNC, 0777)) < 0))
    {
        return error;
    }
    if (unlikely((error = sys_close(error)) < 0))
    {
        return error;
    }

    return 0;
}

static int check_file_xattr(struct inode *inode, const char *name, void *dest, 
    void *def, int len)
{
    int error;
    printk("check %s for inode %lx\n", name, (unsigned long)inode);

    if (unlikely((error = ext2_xattr_get(inode, EXT2_XATTR_INDEX_TRUSTED, 
        name, dest, len)) < 0))
    {
        printk("setting def\n");
        if ((error = (ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, name, 
            def, len, XATTR_CREATE)) < 0))
        {
            printk("failed!\n");
            return error;
        }
        return 0;
    }
    return 0;
}

/*
    check if file has xattr named 'evicted', if not, create one and set the 
    value to 0.
    then return the xattr value 'evicted'.

    returns -1 if error occurs.
*/
static inline int check_file_xattr_evict(struct inode *inode)
{
    int error;
    int value = 0;
    int def = 0;
    error = check_file_xattr(inode, "evicted", &value, &def, 4);
    printk("value %d\n", value);
    return error ? -1 : value;
}

static inline int check_file_xattr_scantime(struct inode *inode)
{
    int error;
    unsigned long value = 0;
    unsigned long def = 0;
    error = check_file_xattr(inode, "scantime", &value, &def, 8);
    printk("value %lu\n", value);
    return error ? -1 : value;
}

static inline int check_file_xattr_clockhand(struct inode *inode)
{
    int error;
    unsigned long value = 0;
    unsigned long def = 0;
    error = check_file_xattr(inode, "clockhand", &value, &def, 8);
    printk("value %lu\n", value);
    return error ? -1 : value;
}

static loff_t i_size;
static struct timespec i_atime;
static struct timespec i_mtime;
static struct timespec i_ctime;
static unsigned int i_blkbits;
static blkcnt_t i_blocks;
static unsigned short i_bytes;
static unsigned long dirtied_when;

static inline int save_inode_metadata(struct inode *inode)
{
    i_size = inode->i_size;
    i_atime = inode->i_atime;
    i_mtime = inode->i_mtime;
    i_ctime = inode->i_ctime;
    i_blkbits = inode->i_blkbits;
    i_blocks = inode->i_blocks;
    i_bytes = inode->i_bytes;
    dirtied_when = inode->dirtied_when;

    return 0;
}

static inline int put_inode_metadata(struct inode *inode)
{
    inode->i_size = i_size;
    inode->i_atime = i_atime;
    inode->i_mtime = i_mtime;
    inode->i_ctime = i_ctime;
    inode->i_blkbits = i_blkbits;
    inode->i_blocks = i_blocks;
    inode->i_bytes = i_bytes;
    inode->dirtied_when  = dirtied_when;

    return sync_inode_metadata(inode, 1);
}


static inline int lock_inode(struct inode *path)
{
    return 0;
}

static inline int unlock_inode(struct inode *path)
{
    return 0;
}

static int is_inode_inuse(struct inode *inode)
{
    struct hlist_node *ite = (inode->i_dentry).first;
    while (ite != NULL)
    {
        struct dentry *dentry = container_of(ite, struct dentry, d_alias);

        spin_lock(&dentry->d_lock);
        if (dentry->d_count != 0)
        {
            printk("inuse\n");
            return 1;
        }
        spin_unlock(&dentry->d_lock);

        ite = ite->next;
    }
    return 0;
}

/* Evict the file identified by i_node to the cloud server, freeing its disk
 * blocks and removing any page cache pages.
 *
 * The call should return when the file is evicted. Besides the file data 
 * pointers, no other metadata, e.g., access time, size, etc. should be 
 * changed. Appropriate errors should be returned. In particular, the operation
 * should fail if the inode currently maps to an open file. Lock the inode
 * appropriately to prevent a file open operation on it while it is being 
 * evicted.
 *
 * Caller must hold evict_mutex. Also, inode should be locked.
 *   to lock an inode: set i_op->permission = {false};
 */
static int do_ext2_evict(struct inode *inode)
{
    int evicted;
    int error;

    printk("evicting\n");

    if (unlikely((error = set_e_filename(inode)) < 0))
    {
        return error;
    }

    if (unlikely((error = lock_inode(inode)) < 0))
    {
        return error;
    }

    save_inode_metadata(inode);

    //printk("meta saved\n");

    if (unlikely((error = send_file(
        e_filename, inode->i_ino, inode->i_size)) < 0))
    {
        return error;
    }

    printk("file sended\n");

    if (unlikely((error = evict_ondisk_file(e_filename)) < 0))
    {
        return error;
    }

    evicted = 1;
    if (unlikely((error = ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
        "evicted", &evicted, 4, XATTR_REPLACE)) < 0))
    {
        int value = 1;
        if ((error = (ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
            "evicted", &value, 4, XATTR_CREATE)) < 0))
        {
            return error;
        }
    }

    //printk("disk released\n");

    if (unlikely((error = put_inode_metadata(inode) < 0)))
    {
        return error;
    }

    //printk("inode recovered\n");

    if (unlikely((error = unlock_inode(inode)) < 0))
    {
        return error;
    }
    return 0;
}

int ext2_evict(struct inode *inode)
{
    mm_segment_t oldfs;
    unsigned long ret = 0;
    int evicted;

    if (is_inode_inuse(inode))
    {
        printk("evict: inuse\n");
        return -EINVAL;
    }

    evicted = check_file_xattr_evict(inode);

    printk("xattr_evict %d\n", evicted);
    if (evicted < 0)
    {
        return evicted;
    }
    else if (evicted == 1)
    {
        return 0;
    }

    check_evict_mutex();
    mutex_lock(&evict_mutex);
    
	oldfs = get_fs();
	set_fs(KERNEL_DS);
    ret = do_ext2_evict(inode);
    set_fs(oldfs);

    mutex_unlock(&evict_mutex);

    printk("evict: %lu\n", ret);
    return ret;
}

int ext2_evict_with_prev_lock(struct inode *inode)
{
    mm_segment_t oldfs;
    unsigned long ret = 0;
    int evicted;

    if (is_inode_inuse(inode))
    {
        printk("evict: inuse\n");
        return -EINVAL;
    }

    evicted = check_file_xattr_evict(inode);

    printk("xattr_evict %d\n", evicted);
    if (evicted < 0)
    {
        return evicted;
    }
    else if (evicted == 1)
    {
        return 0;
    }

	oldfs = get_fs();
	set_fs(KERNEL_DS);
    ret = do_ext2_evict(inode);
    set_fs(oldfs);

    printk("evict: %lu\n", ret);
    return ret;
}


/* Fetch the file specified by i_node from the cloud server. The function 
 * should allocate space for the file on the local filesystem. No other meta-
 * data of the file should be changed. Lock the inode appropriately to prevent
 * concurrent fetch operations on the same inode, and return appropriate 
 * errors.
 *
 * Caller must hold evict_mutex. Also, inode should be locked.
 */
static int do_ext2_fetch(struct inode *inode)
{
    int evicted;
    int error;

    if (unlikely(error = lock_inode(inode)) < 0)
    {
        return error;
    }

    //printk("inode locked\n");

    if (unlikely((error = set_f_filename(inode)) < 0))
    {
        return error;
    }
    
    //printk("got path\n");

    save_inode_metadata(inode);

    if (unlikely((error = receive_file(f_filename, inode->i_ino)) < 0))
    {
        return error;
    }

    //printk("file received\n");

    evicted = 0;
    if (unlikely((error = ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
        "evicted", &evicted, 4, XATTR_REPLACE)) < 0))
    {
        int value = 0;
        if ((error = (ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, 
            "evicted", &value, 4, XATTR_CREATE)) < 0))
        {
            return error;
        }
    }

    //printk("xattr set\n");

    if (unlikely((error = put_inode_metadata(inode) < 0)))
    {
        return error;
    }

    //printk("inode recovered\n");

    if (unlikely((error = unlock_inode(inode)) < 0))
    {
        return error;
    }

    return 0;
}

int ext2_fetch(struct inode *inode)
{
    static struct task_struct *task = NULL;
    unsigned long ret = 0;
    mm_segment_t oldfs;
    int evicted;

    //printk("task %lx, in_fetch %d\n", (unsigned long)task, in_fetch);

    if (task == current)
    {
        //printk("to avoid deadlock...\n");
        return 23333;
    }

    evicted = check_file_xattr_evict(inode);
    if (evicted < 0)
    {
        return evicted;
    }
    else if (evicted == 0)
    {
        return 0;
    }

    check_fetch_mutex();
    mutex_lock(&fetch_mutex);

	oldfs = get_fs();
	set_fs(KERNEL_DS);
    task = current;
    ret = do_ext2_fetch(inode);
    task = NULL;
    set_fs(oldfs);

    mutex_unlock(&fetch_mutex);
    
    printk("fetch: %lu\n", ret);
    return ret;
}

void ext2_evict_void(struct inode *inode, void *arg)
{
    int value;
    int turn = *((int*)arg) / 100;
    int target = *((int*)arg) % 100;

    if (turn == 0 && inode->i_ino < clockhand)
    {
        return;
    }

    if (is_inode_inuse(inode))
    {
        return;
    }

    if (fs_filled(inode->i_sb) <= target)
    {
        return;
    }

    // we don't mean to evict directories.
    if (ext2_xattr_get(inode, EXT2_XATTR_INDEX_TRUSTED, "parent_ino", 
        &value, 4) < 0)
    {
        return;
    }
    else
    {
        unsigned long scan_time;
        unsigned long access_time; 
        printk("regular file\n");
        scan_time = check_file_xattr_scantime(inode);
        access_time = inode->i_atime.tv_sec;

        if (access_time > scan_time)
        {
            ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, "scantime", 
                &access_time, 8, XATTR_REPLACE);
        }
        else
        {
            printk("should evict\n");
            ext2_evict_with_prev_lock(inode);
            clockhand = inode->i_ino;
        }

    }
}

int ext2_evict_fs_until(struct super_block *super, int target)
{
    int arg = target;
    struct inode *inode = super->s_root->d_inode;

    check_evict_mutex();
    mutex_lock(&evict_mutex);

    clockhand = check_file_xattr_clockhand(inode);

//    for_each_inode(super, ext2_evict_void, NULL);

    printk("clockhand: %lu\n", clockhand);

    if (fs_filled(inode->i_sb) > target)
    {
        for_each_inode(super, ext2_evict_void, &arg);
    }

    printk("turn 2\n");
    arg = target + 100;
    if (fs_filled(inode->i_sb) > target)
    {
        for_each_inode(super, ext2_evict_void, &arg);
    }
    printk("turn 3\n");
    if (fs_filled(inode->i_sb) > target)
    {
        for_each_inode(super, ext2_evict_void, &arg);
    }

    ext2_xattr_set(inode, EXT2_XATTR_INDEX_TRUSTED, "clockhand", 
        &clockhand, 8, XATTR_REPLACE);


    mutex_unlock(&evict_mutex);
    printk("end evict process\n");
    return 0;
}

int ext2_evict_fs(struct super_block *super)
{
    return ext2_evict_fs_until(super, evict_target);
}

static void check_evict(struct inode *inode)
{
    struct ext2_sb_info *sbi = EXT2_SB(sb);
    struct ext2_super_block *es = sbi->s_es;

    unsigned long total = es->s_blocks_count;

    unsigned long reserve = total - (total * high_watermark) / 100;
    unsigned long need = inode->i_size / sb->s_blocksize;
    unsigned long used = total - ext2_count_free_blocks(sb);

    printk("total %lu, reserve %lu, used %lu, need %lu\n", 
        total, reserve, used, need);

    if (used + need + reserve >= total)
    {
        unsigned long target = (100 * (total - reserve - need)) / total;

        target = target < evict_target ? target : evict_target;
        printk("need evict\n");
        ext2_evict_fs_until(sb, target);
    }
}

void ext2_fetch_waiting(void)
{
    struct inode *inode = ext2_iget(sb, ino_to_fetch);

    printk("wait inode %lx\n", (unsigned long)inode);

    check_evict(inode);

    printk("in_fetch set!\n");
    in_fetch = 1;
    ext2_fetch(inode);
    in_fetch = 0;
    printk("in_fetch reset!\n");

    iput(inode);
}
EXPORT_SYMBOL(ext2_fetch_waiting);

int evictable_ext2_file_open(struct inode *inode, struct file *file)
{
    int evicted;
    printk("open with in_fetch=%d\n", in_fetch);

    if (!in_fetch)
    {
        evicted = check_file_xattr_evict(inode);
        if (evicted != 0)
        {
            printk("activate 23333 mode\n");
            ino_to_fetch = inode->i_ino;
            sb = inode->i_sb;
            return -ECONNRESET;
        }
    }
    else
    {
        printk("bypass!\n");
    }

    return dquot_file_open(inode, file);
}

ssize_t evictable_ext2_file_write(struct file *filp, const char __user *buf, 
    size_t len, loff_t *ppos)
{
    if (fs_filled(filp->f_dentry->d_sb) > high_watermark)
    {
        printk("write: evict\n");
        ext2_evict_fs(filp->f_dentry->d_sb);
    }

    return do_sync_write(filp, buf, len, ppos);
}

static int find_substring(const char *str, const char *pat)
{
    int i = 0;
    int j = 0;
    for (; str[i]; ++i)
    {
        for (j = 0; pat[j]; ++j)
        {
            if (str[i + j] != pat[j])
            {
                break;
            }
        }
        if (!pat[j])
        {
            return i;
        }
    }
    return -1;
}

static unsigned atou(const char *str)
{
    unsigned res = 0;
    int i = 0;
    for (; str[i]; ++i)
    {
        if (str[i] < 48 || str[i] > 57)
        {
            break;
        }
        res = (res * 10) + str[i] - 48;
    }
    return res;
}

static int find(const char *p, char c, int start)
{
    int i = start;
    while (p[i])
    {
        if (p[i] == c)
        {
            return i;
        }
        ++i;
    }
    return -1;
}

static int set_server(char *p)
{
    int split = -1;
    int i = 0;
    int j = 0;
    int port;

    for (i = 0; i < 3; ++i)
    {
        j = find(p, '.', split + 1);
        if (j == -1)
        {
            return 0;
        }
        p[j] = 0;
        if (atou(p + (split + 1)) > 255)
        {
            return 0;
        }
        p[j] = '.';
        split = j;
    }

    j = find(p, ':', split + 1);
    if (j == -1)
    {
        return 0;
    }
    p[j] = 0;
    if (atou(p + (split + 1)) > 255)
    {
        return 0;
    }
    if ((port = atou(p + (j + 1))) > 65535)
    {
        return 0;
    }

    cloud_port = port;
    for (i = 0; p[i]; ++i)
    {
        cloud_ip[i] = p[i];
    }
    p[j] = ':';

    return 1;
}

static int set_wh(const char *p)
{
    unsigned wh = atou(p);
    if (wh > 100)
    {
        return 0;
    }
    high_watermark = wh;
    return 1;
}

static int set_wl(const char *p)
{
    unsigned wl = atou(p);
    if (wl > high_watermark)
    {
        return 0;
    }
    low_watermark = wl;
    return 1;
}

static int set_evict(const char *p)
{
    unsigned evict = atou(p);
    if (evict > low_watermark)
    {
        return 0;
    }
    evict_target = evict;
    return 1;
}

int parse_evict_options(char *data)
{
    static char *server_prefix = "srv=";
    static char *hw_prefix = "wh=";
    static char *lw_prefix = "wl=";
    static char *evict_prefix = "evict=";
    int ind;
    int term;
    char c;

    if (data == NULL)
    {
        return -1;
    }

    printk("set server\n");

    if ((ind = find_substring(data, server_prefix)) < 0)
    {
        return -1;
    }
    term = find(data, ' ', ind);
    if (term != -1)
    {
        c = data[term];
        data[term] = 0;
    }
    if (!set_server(data + ind + 4))
    {
        return -1;
    }
    if (term != -1)
    {
        data[term] = c;
    }

    printk("set hw\n");

    if ((ind = find_substring(data, hw_prefix)) < 0)
    {
        set_wh("95");
        goto setlw;
    }
    term = find(data, ' ', ind);
    if (term != -1)
    {
        c = data[term];
        data[term] = 0;
    }
    if (!set_wh(data + ind + 3))
    {
        return -1;
    }
    if (term != -1)
    {
        data[term] = c;
    }
setlw:

    printk("set lw\n");

    if ((ind = find_substring(data, lw_prefix)) < 0)
    {
        set_wl("85");
        goto setevict;
    }
    term = find(data, ' ', ind);
    if (term != -1)
    {
        c = data[term];
        data[term] = 0;
    }
    if (!set_wl(data + ind + 3))
    {
        return -1;
    }
    if (term != -1)
    {
        data[term] = c;
    }
setevict:
    
    printk("set evict\n");

    if ((ind = find_substring(data, evict_prefix)) < 0)
    {
        set_evict("70");
        goto out;
    }
    term = find(data, ' ', ind);
    if (term != -1)
    {
        c = data[term];
        data[term] = 0;
    }
    if (!set_evict(data + ind + 6))
    {
        return -1;
    }
    if (term != -1)
    {
        data[term] = c;
    }
    
out:
    printk("server: %s:%d\n", cloud_ip, cloud_port);
    printk("wh: %d, wl: %d, evict: %d\n", 
        high_watermark, low_watermark, evict_target);
    printk("mount complete\n");
    return 0;
}